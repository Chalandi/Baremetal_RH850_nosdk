# Overview

The Renesas Flash Programmer (hereafter referred to as the RFP) is software that uses an E1 emulator (hereafter referred to as the E1), E20 emulator (hereafter referred to as the E20), E2 emulator (hereafter referred to as the E2), E2 emulator Lite (hereafter referred to as the E2 Lite), or J-Link Debug Probe  (hereafter referred to as the J-Link) via a serial, USB or SWD interface to erase, write, and verify programs for a target device on a target system.

This document describes the command line options for manipulating the RFP on Linux, Windows and macOS.
## Supported Operating Systems
* Linux (Ubuntu 22.04 LTS, x64/ARM32/ARM64)
* Linux (Ubuntu 24.04 LTS, x64/ARM64)
* Windows 10 (32-bit and 64-bit)
* Windows 11
* macOS 15 Sequoia (Apple Silicon)
* macOS 26 Tahoe (Apple Silicon)

## Operating Environment
This application require the following library, but it is already installed with macOS.
* libusb-1.0-0

This application uses .NET 8. 
.NET 8 libraries are included in this application, but additional libraries may be required.  
Refer to the following URL for details.  
https://docs.microsoft.com/dotnet/core/install/linux

## Restrictions
Linux and macOS do not support E1 emulator and E20 emulator.  
macOS does not support boot mode with the USB interface of the RA family.  
Under macOS, depending on the OS version, UART (serial port) communications may not be available or may be limited.  
ARM32 is not supported by Ubuntu 24.04 LTS and later versions.  

## Installation
### To use the Renesas emulator on Linux (udev rules)
1. Type `sudo cp 99-renesas-emu.rules /etc/udev/rules.d/`
1. Type `sudo udevadm control --reload-rules` or `service udev restart`
1. Connect the emulator tool to your PC

## Command Line
The rfp-cli command makes control from a command line possible.

## Exit Code 
When the operation was successful, exit code 0 is returned.
Otherwise, exit code 1 is returned.

## Command-line Syntax 
`rfp-cli [option...] [hexfile...]`

Option names are prefixed by a hyphen (-) or a slash (/).

# Options for Help
Note that options in this group have higher priority than other options and stop processing successfully when the display is completed.

## -version, -ver
Shows the version messages.

Example:
```
rfp-cli -ver
```

## -help, -h, -?
Shows messages on usage.

Example:
```
rfp-cli -h
```

## -list-devices, -ld 
Shows a list of supported devices.

Example:
```
rfp-cli -ld
```

## -list-tools, -lt 
Shows a list of connected tools.  
To use this option, the `-device` option must also be specified.

Example:
```
rfp-cli -d RA -lt
```

## -list-ports, -lp 
Shows a list of connected COM ports.  
To use this option, the `-device` option must also be specified.

Example:
```
rfp-cli -d RA -lp
```

## -list-interfaces, -li 
Shows a list of communications interfaces.  
To use this option, the `-device` option and the `-tool` or `-port` option must also be specified.

Example:
```
rfp-cli -d RA -t e2 -li
```

## -list-speeds, -ls 
Shows a list of supported communications speeds.  
To use this option, the `-device` option must also be specified.  
This option requires a connection between the RFP and the device.

Example:
```
rfp-cli -d RA -t e2 -ls
```

## -list-flashoptions, -lfo 
Shows supported flash options.  
To use this option, the `-device` option must also be specified.  
This option requires a connection between the RFP and the device.

Example:
```
rfp-cli -d RA -t e2 -lfo
```

# Options for Connection

## -device \<name>, -d \<name>
Selects a device type.  

### \<name>  
Specifies a device type string. If the device name includes spaces, enclose the string in double-quotation marks.  
The device type can be obtained with the `-list-devices` option.  

Refer to the list of supported devices for the type to be specified as the device name.  
This option is always required, except with some show options.

Example:
```
rfp-cli -d RA -t e2 <commands...>
rfp-cli -d "Renesas Synergy" -port COM3 <commands...>
```

## -tool \<type>[:\<serial>], -t \<type>[:\<serial>]
Selects the emulator hardware and the serial number.  
If this option is omitted, the `-port` option is always required, except with some show options.

### \<type>
Select the type from the following list.
|Type|Meaning|
|---|---|
|e1|E1 emulator (Windows only)|
|e20|E20 emulator (Windows only)|
|e2|E2 emulator|
|e2l|E2 emulator Lite|
|jlink|J-Link|
|usb|USB Direct|

### \<serial> (Optional)  
Specifies all or part of the serial number of the connected hardware.  
If this option is omitted, the first tool to be found is connected to the RFP.

> **Note (J-Link only)**  
> For J-Link, the `<serial>` parameter can be specified in multiple forms, including:
> 
> - a **serial number** of the J-Link device
> - a **nickname** assigned to the J-Link device  
>   - The nickname must contain **at least one non-numeric character**.
>
> When the `-use-ip` option is specified, the `<serial>` parameter can also be specified using an **IP-based format**, following the same syntax as the IP command used in J-Link Commander.  
> For more information, refer to the J-Link related manuals.
>
> Example:
> ```
> rfp-cli -d RA -t jlink:600100000 <commands...>
> rfp-cli -d RA -t jlink:192.168.0.1 <commands...>
> rfp-cli -d RA -t jlink:192.168.0.1:1234 <commands...>
> rfp-cli -d RA -t jlink:tunnel:932000000:MyPassword123:jlink2.segger.com <commands...>
> rfp-cli -d RA -t jlink:ThisIsANickname <commands...>
> ```

## -use-ip
Enables IP connection for Segger J-Link.  
This option is only valid when `jlink` is specified for the `-tool` option.  
When this option is specified, J-Link uses an IP connection instead of a USB connection.  
The IP address or hostname is specified in the `<serial>` part of the `-tool` option.

Example:
```
rfp-cli -d RA -t jlink:192.168.0.1 -use-ip <commands...>
```

## -port \<name>
Selects the serial port (COM port) for communication.  
If this option is omitted, the `-tool` option is always required, except with some show options.

Example:
```
rfp-cli -d RA -port COM3 <commands...>
rfp-cli -d RA -port /dev/ttyS0 <commands...>
```

## -interface \<type>, -if \<type>
Selects the communications interface.  
If this option is not specified, a value is automatically selected.

### \<type>
Select the type from the following list.
|Type|Meaning|
|---|---|
|uart1|1 wire UART|
|uart|2 wire UART|
|fine|FINE|
|csi|CSI|
|swd|SWD (*1)|
|uart-bridge|UART Bridge|

\*1)  
For the SWD interface, some functions are not available for some devices.  
For details, refer to Chapter 5, Points for Caution, in the Renesas Flash Programmer User's Manual. 

Example:
```
rfp-cli -d RL78 -t e2 -if uart1 <commands...>
```

## -speed \<num>[K|M], -s \<num>[K|M]
Specifies the baud rate or communications speed.  
If this option is not specified, a value is automatically selected.

### \<num>
Specifies the baud rate [bps] or communications speed [Hz].  

Example:
```
rfp-cli -d RA -t e2 -if uart -s 9600 <commands...>
rfp-cli -d RA -t e2 -if uart -s 1.5M <commands...>
```

## -voltage \<num>, -vo \<num>
Enables the supply of power.  
To use this option, the `-tool` option must also be specified.  
If this option is not specified, the output power is disabled and an external power supply is used.

### \<num>
Specifies the output voltage [V].  

Example:
```
rfp-cli -d RA -t e2 -if uart -vo 3.3 <commands...>
```

## -widevoltage, -wv
Enables the wide voltage mode of an RL78 device that has this function.  
If it does not, this option is ignored.

Example:
```
rfp-cli -d RL78 -t e2 -vo 3.3 -wv <commands...>
```

## -iomode \<mode>
Selects the setting of the tool mode at device connection.  
To use this option, the `-tool` option must also be specified.

### \<mode>
Select the mode from the following list.
|Mode|Description|
|---|---|
|auto|Sets mode pins automatically (default).
|manual|If the `-io` option is not specified for all pins, pins not specified are in the hi-Z state.

Example:
```
rfp-cli -d RA -t e2 -iomode auto <commands...>
```

## -io\<n> \<signal>
Sets mode pins manually.  
This option can be specified more than once.  
To use this option, the `-tool` and `-iomode` options must also be specified.  
The RFP ignores this option if the `-iomode` option is set for automatic mode.  

Each mode pin is in the hi-Z state by default.

### \<n>
Selects the mode pin number (0 to 5).  
For pin assignments of io0 to io5 for the E1, E20, E2, and E2 Lite, refer to the following URL for details. 
https://www.renesas.com/document/mat/pg-fp6-renesas-flash-programmer-additional-document-users-manual-recommended-circuits-connecting 

### \<signal>
Select the signal from the following list.  
|Signal|Meaning|
|---|---|
|low|Driven low|
|high|Driven high|

Example:
```
rfp-cli -d RA -t e2 -if uart -iomode manual -io0 high <commands...>
```

## -run
Releases the reset signal and causes the target device to run after disconnection. This option applies only if the operation was successful. In case of failure, this option is treated as the `-reset` option.  
If both the `-run` and `-reset` options are specified, the last option to have been specified is used.

Example:
```
rfp-cli -d RA -t e2 -p -run application.mot
```

## -reset
Resets the target device after disconnection. This option is enabled by default.  
If both the `-run` and `-reset` options are specified, the last option to have been specified is used.

Example:
```
rfp-cli -d RA -t e2 -reset <commands...>
```

## -dtr
Uses the DTR signal as the reset signal for the COM port.  
If both the -dtr and -dtr-inv options are specified, the last option to have been specified is used.  
To use this option, the `-port` option must also be specified.  

There is no reset signal on the COM port (default).

Example:
```
rfp-cli -d RA -port COM3 -if uart -dtr -rts-inv <commands...>
```

## -dtr-inv
Uses the DTR signal as the reset signal for the COM port (inverted reset signal).  
If both the "-dtr" and "-dtr-inv" options are specified, the last option to have been specified is used.  
To use this option, the `-port` option must also be specified.  

There is no reset signal on the COM port (default).

Example:
```
rfp-cli -d RA -port COM3 -if uart -dtr-inv -rts <commands...>
```

## -rts
Uses the RTS signal as the reset signal for the COM port.  
If both the "-rts" and "-rts-inv" options are specified, the last option to have been specified is used.  
To use this option, the `-port` option must also be specified.  

There is no reset signal on the COM port (default).

Example:
```
rfp-cli -d RA -port COM3 -if uart -rts -dtr-inv <commands...>
```

## -rts-inv
Uses the RTS signal as the reset signal for the COM port (inverted reset signal).  
If both the "-rts" and "-rts-inv" options are specified, the last option to have been specified is used.  
To use this option, the `-port` option must also be specified.  

There is no reset signal on the COM port (default).

Example:
```
rfp-cli -d RA -port COM3 -if uart -rts-inv -dtr <commands...>
```

## -reset-flipflop
Uses the Flip-Flop control reset signal for the COM port.  
To use this option, the `-port` option must also be specified.  

There is no reset signal on the COM port (default).

Example:
```
rfp-cli -d RA6B1 -port COM3 -if uart -reset-flipflop <commands...>
```

## -osc \<freq>
Specifies the frequency of the main clock.  
This option is only required for some devices (e.g. RH850).  
The RFP ignores this option, if the target device does not require a main clock setting.  
If this option is not specified for a device that requires main clock configuration, a console prompt will be displayed.

### \<freq>
Specifies the main clock frequency as a decimal number in MHz.

Example:
```
rfp-cli -d RH850 -t e2 -osc 16.0 <commands...>
```

## -auth \<type> \<code>
Specifies authentication codes.  
This option can be specified more than once.  
The RFP ignores this option, if the target device does not require an authentication code.  
If this option is not specified for a device that requires authentication, a console prompt will be displayed.

### \<type>
Select the type from the following list.  
|Type|Meaning|
|---|---|
|id|ID code|
|cfpw|Code Flash Access Password|
|dfpw|Data Flash Access Password|
|oid|OCD ID|
|cid|Customer ID|
|cida|Customer ID A|
|cidb|Customer ID B|
|cidc|Customer ID C|
|ctid|C-Test ID|
|sifid|RHSIF ID|
|dfid|Data Flash ID|
|seckey|SECDBG Key|
|nonseckey|NONSECDBG Key|
|rmakey|RMA Key|
|al2key|AL2 Key|
|al1key|AL1 Key|

### \<code>
Specifies the authentication code in hexadecimal.

Example:
```
rfp-cli -d RX65x -t e2 -auth id FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF <commands...>
```

## -endian \<endian>
Selects the endian of a bi-endian device.  
This option does not configure the endian setting of the target device; it informs the target device of the endian format to be used.

### \<endian>
Select the endian from the following list.  
|Endian|Meaning|
|---|---|
|little|Little-endian (default)|
|big|Big-endian|

Example:
```
rfp-cli -d RX65x -t e2 -endian big <commands...>
```

## -svr-override
Override the SVR parameters using the parameters in the program file.  
For the "-svr-override" and "-svr-disable" options, the option specified last is used.  
If the target device does not support this function, this option is ignored.

Example:
```
rfp-cli -d RH850/U2x -t e2 -osc 20 -svr-override <commands...>
```

## -svr-disable
Forcibly disable the SVR function.  
For the "-svr-override" and "-svr-disable" options, the option specified last is used.  
If the target device does not support this function, this option is ignored.

Example:
```
rfp-cli -d RH850/U2x -t e2 -osc 20 -svr-disable <commands...>
```

## -swas-recover
Performs SWAS-Recover on the device.  
If this option is specified, no other flash memory operation options can be specified at the same time.

Example:
```
rfp-cli -d RH850/U2x -t e2 -osc 20 -swas-recover
```

## -run-user-image <file>
This option specifies the image binary of user application.  
If this option specified, the command terminates after downloading the selected image, and no other operations are performed.  
If the target device does not support this function, an unsupported error occurs.

### \<file>
User image file path. If the file path includes spaces, enclose the string in double-quotation marks.  
Only raw binary formats (.bin, .img) are supported.

Example:
```
rfp-cli -d RA6W1 -port COM3 -run-user-image application.bin
```

## -set-boot-image <file>
This option specifies the boot image binary used for memory programming (such as provisioning software).
If the target device does not support this function, an unsupported error occurs. 

### \<file>
The boot image file path. If the file path includes spaces, enclose the string in double-quotation marks.
Only raw binary formats (.bin, .img) are supported.

Example:
```
rfp-cli -d RA6B1 -port COM3 -if uart -set-boot-image provisioning.bin -reset-flipflop <commands...>
```

## -cr
Performs challenge and response authentication manually.  
By default, the RFP handles challenge and response authentication automatically.  
When this option is specified, the RFP displays the challenge value and the user must enter the corresponding response value.  
If this option is specified, any authentication codes specified by the -auth option are ignored for devices that support challenge and response authentication.  
The RFP ignores this option if the target device does not support challenge and response authentication. 

Example:
```
rfp-cli -d RA6B1 -port COM3 -if uart -cr -dlm OEM_PL2 -reset-flipflop
```

# Options for the Target Area
Note that the specifications are made in the order of `-fill`, `-range`, and `-range-exclude`.

## -range \<start addr>,\<end addr>
Specifies the target address range.  
This option can be specified more than once.  
The `-range-exclude` option takes priority over the `-range` option.

The whole flash address range is specified by default.

### \<start addr>
Specifies the start address of the target range in hexadecimal.

### \<end addr>
Specifies the end address of the target range in hexadecimal.

Example:
```
rfp-cli -d RA -t e2 -range 0,3FFF <commands...>
rfp-cli -d RA -t e2 -range 0,3FFF -range 8000,FFFF <commands...>
```

## -range-exclude \<start addr>,\<end addr>
Specifies the non-target address range.  
This option can be specified more than once.  
The `-range-exclude` option takes priority over the `-range` option.

### \<start addr>
Specifies the start address of the non-target range in hexadecimal.

### \<end addr>
Specifies the end address of the non-target range in hexadecimal.

Example:
```
rfp-cli -d RA -t e2 -range-exclude 4000,7FFF <commands...>
rfp-cli -d RA -t e2 -range-exclude 4000,7FFF -range-exclude 10000,FFFFF <commands...>
```

## -fill \<area>
Fills the empty space with 0xFF when writing to the device.  
The `-range` and `-range-exclude` options take priority over the `-fill` option.

### \<area>
Select the area from the following list.  
|Area|Description|
|---|---|
|all|Fills code flash, user boot and data flash.|
|code|Fills code flash and user boot.|
|data|Fills data flash.|

Example:
```
rfp-cli -d RA -t e2 -p -fill code data.mot
```

# Options for Data
Note that files and data are applied in the order of "-file", "-bin", and "-data".

## [-file] \<hex file>
Loads and uses a specified hex file for writing to and verification in the device.  
This option can be specified more than once, and the option name can be omitted.  
Files cannot be specified with data for the same addresses.

### \<hex file>
File path. If the file path includes spaces, enclose the string in double-quotation marks.  
The following file formats or encrypted files (RPE files) in these formats can be specified.  
\- Intel Hex  
\- Motorola S-Record  
\- RPI file (Renesas Flash Programmer Image File) (*1)  
\- HCUHEX (*1)  
\- SFP file (Secure Factory Programming File) (*1, *2)  

\*1) If this file is specified, the following restrictions apply.  
\- The following options cannot be specified:  
`-range`, `-range-exclude`, and `-flashoption`  
\- Multiple files cannot be specified with this option.

\*2) If this file is specified, the following restrictions apply.  
\- The following options cannot be specified:  
`-verify` and `-fill`

Example:
```
rfp-cli -d RA -t e2 -p data1.mot data2.mot
```

## -file-offset \<offset> \<hex file>
Add the specified offset value when reading a hex file.

### \<offset>
Offset value to be added (hexadecimal).

### \<hex file>
File path. If the file path includes spaces, enclose the string in double-quotation marks.  
The following file formats can be specified.  
\- Intel Hex  
\- Motorola S-Record

Example:
```
rfp-cli -d RA -t e2 -p -file-offset 80 data.mot
```

## -bin \<addr> \<file>
Loads and uses a specified binary file for writing to and verification in the device.  
This option can be specified more than once.  
This option is processed after the "-file" option, and all data in the given range are overwritten.

### \<addr>
Flash memory address (hexadecimal).

### \<file>
File path. If the file path includes spaces, enclose the string in double-quotation marks.

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -p -bin FF200000 data.bin
```

## -data \<addr> \<data>
Uses a specified data for writing to and verification in the device.  
This option can be specified more than once.  
This option is processed after `-file` and `-bin` options, and all data in the given range are  overwritten.

### \<addr>
Flash memory address (hexadecimal).

### \<data>
Data (hexadecimal).

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -p -data FF200000 0123456789ABCDEF
```
 
## -rpe-password \<password>
Specifies a file password for opening an RPE file.

### \<password>
Specifies a password string.  
If the password includes symbols, enclose the string in double-quotation marks.

Example:
```
rfp-cli -d RA -t e2 -p data.rpe -rpe-password ABCD1234EFGH5678
rfp-cli -d RA -t e2 -p data.rpe -rpe-password "ABCD1234!@#EFGH5678"
```

## -userkey \<addr> \<file>
Loads and uses a specified key file as the TSIP user key for writing to and verification in the device.  
This option can be specified more than once.  
This option can only be specified if the device supports this function. For more information, refer to the user's manual of the target device.

### \<addr>
Flash memory address (hexadecimal).

### \<file>
Renesas key file path. If the file path includes spaces, enclose the string in double-quotation marks.  
The key file can be created by the Security Key Management Tool.

Example:
```
rfp-cli -d RA -t e2 -p -userkey 400 data.rkey
```

## -flashoption \<type> \<data>, -fo \<type> \<data>
Uses a specified device flash options for writing to and verification in the device.  
This option can be specified more than once.  
Only options supported by the target device can be specified.

### \<type>
Refer to the "Flash options list" section.

### \<data>
Refer to the "Flash options list" section.

# Options for Flash Action
Note that specifying an option that is not supported by the device leads to an error.  
Note that these actions cannot be performed at the same time as those in from other groups.

## -auto, -a
Erases, writes, and verifies flash memory in the device.  
This option has the same effect as specifying `-erase`, `-program`, and `-verify`.

Example:
```
rfp-cli -d RA -t e2 -a data.mot
```

## -pv
Writes and verifies flash memory in the device.  
This option has the same effect as specifying `-program` and `-verify`.

Example:
```
rfp-cli -d RA -t e2 -pv data.mot
```

## -erase, -e
Erases flash memory of the device.  
The range options determine the range for erasure.  
If the target device does not support this function, this option is ignored.

Example:
```
rfp-cli -d RA -t e2 -e
```

## -program, -p
Erases the range for writing to the device and writes to the device.  
The specified hex file and range options determine the ranges for erasure and writing.  

The following options can also be used to write data:  
`-file`, `-bin`, `-data`, `-flashoption`, and `-userkey`

Example:
```
rfp-cli -d RA -t e2 -p data.mot
```

## -verify, -v
Verifies the data that have been written to the device.  
The range for verification is the same as that for the `-program` option.

The following options can be used to restrict the range of verification:  
`-noverify-id` and `-noverify-fo`  
If the target device does not support this function, this option is ignored.

Example:
```
rfp-cli -d RA -t e2 -v data.mot
```

## -sig
Shows the device signature.

Example:
```
rfp-cli -d RA -t e2 -sig
```

## -blankcheck
Checks if the flash memory of the device is blank and outputs the result to the console.  
The range options determine the range for blank checking.  
The `-blankcheck-mode` option can be used to stop processing depending on the result.

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -blankcheck
```

## -checksum, -c
Shows the checksum of the flash memory in the device.  
The range options determine the checksum range.  
If the device supports multiple checksum algorithms, use the `-crc` or `-checksum-type` option.  
To calculate the checksum of a file, specify the `-checksum-file` option.

Example:
```
rfp-cli -d RA -t e2 -c
```

## -checksum-file, -cf
Shows the flash memory checksum of a file.  
The range for calculation and algorithm are the same as those for the `-checksum` option.

Example:
```
rfp-cli -d RA -t e2 -cf data.mot
```

## -checksum-type \<type>
Uses the specified checksum algorithm.  
If the target device does not support the specified algorithm, this option is ignored.

### \<type>
Selects the type from the following list.  
|Type|Meaning|
|---|---|
|auto|Set the type automatically (default).|
|crc|CRC method (*1)|
|add16|16bit additive method (*2)|

\*1) This type has the same effect as specifying the `-crc` option.   
\*2) This type is supported for the RL78 family (excluding the RL78/G10, G1M, G1N, G15, and G16).

Example:
```
rfp-cli -d RA -t e2 -c -checksum-type auto
```

## -crc
Uses the CRC algorithm in the checksum command.  
If the target device does not support this function, this option is ignored.

Example:
```
rfp-cli -d RA -t e2 -c -crc
```

## -write-rpi \<file>
Writes data to an RFP image file (RPI file).  
The data for writing are the same as for the `-program` option.  
If the target file already exists, it is overwritten.    
This operation requires a connection to the device.  
This option is not used when the image file is to be loaded.

### \<file>
Output file path. If the file path includes spaces, enclose the string in double-quotation marks.

Example:
```
rfp-cli -d RA -t e2 data1.mot data2.mot -write-rpi output_data.rpi
```

## -output-file \<type> \<file>
This option will merge the specified user data and output them as a file.   
If the target file already exists, it is overwritten.  

The differences from the `-write-rpi` option are as follows:  
- No connection to the device is required for this operation.
- This option does not allow the `-fill` option to be specified.
- Even in the minimum unit of programming by the MCU, filling of 0xFF is not performed. 
- The address range is not checked.

### \<type>
Select the type from the following list.  
|Type|Meaning|
|---|---|
|srec|Motorola S-Record|
|hex|Intel Hex|
|rpi|RPI file|

### \<file>
Output file path. If the file path includes spaces, enclose the string in double-quotation marks.

Example:
```
rfp-cli -d RA data1.mot data2.mot -output-file rpi output_data.rpi
```

## -blankcheck-mode \<mode>
Stops processing before erasure according to the result of a blankcheck.  
When processing is stopped, exit code 1 is returned.

### \<mode>
Select the mode from the following list.  
|Mode|Description|
|---|---|
|none|Shows the result only (default).|
|blank|Shows the result and stops processing when the result is not blank.|
|notblank|Shows the result and stops processing when the result is blank.|

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -blankcheck -blankcheck-mode blank
```

## -verifybytransfer
Uses the retransfer verification method.  
If the target device does not support this function, this option is ignored.

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -v -verifybytransfer data.mot
```

## -noerase
Skips erasing of the device.

Example:
```
rfp-cli -d RA -t e2 -a -noerase data.mot
```

## -noautoerase
Skips erasing before programming of the device.

Example:
```
rfp-cli -d RA -t e2 -a -noautoerase data.mot
```

## -noverify-id
Skips verifying the device ID code.

Example:
```
rfp-cli -d RX66x -t e2 -pv -noverify-id data.mot
```

## -noverify-fo
Skips verifying the device flash options.

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -pv -fo lb 0,1FFF -noverify-fo

```

## -nocheck-range
Processing is not stopped if the specified hex file exceeds the device's memory range.

Example:
```
rfp-cli -d RA -t e2 -pv -nocheck-range data.mot
```

## -read-flashoptions, -rfo
Reads flash options from the device and outputs the data that have been read to the console.  
No other options for flash memory operation can be specified at the same time as this read option.

Example:
```
rfp-cli -d RA -t e2 -rfo
```

## -read \<file>, -r \<file>
Reads all flash memory data from the device and outputs the data that have been read to the file.  
If the target file already exists, it is overwritten.  
No other options for flash memory operation can be specified at the same time as this read option.

This option does not support the RL78 family.

### \<file>
Output file path. If the file path includes spaces, enclose the string in double-quotation marks.

Example:
```
rfp-cli -d RA -t e2 -r read_data.mot -range 0,3FFFF
```

## -read-bin \<addr> \<size> \<file>, -rb \<addr> \<size> \<file>
Reads flash memory data within the specified range from the device and outputs the data that have been read to the file.  
If the target file already exists, it is overwritten.  
No other options for flash memory operation can be specified at the same time as this read option.

This option does not support the RL78 family.

### \<addr>
Flash memory address (hexadecimal).

### \<size>
Read size [byte] (decimal).

### \<file>
Output file path. If the file path includes spaces, enclose the string in double-quotation marks.

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -rb FF200000 4096 read_data.bin
```

## -read-view \<addr> \<size>, -rv  \<addr> \<size>
Reads flash memory data within the specified range from the device and outputs the data that have been read to the console.  
No other options for flash memory operation can be specified at the same time as this read option.

This option does not support the RL78 family.

### \<addr>
Flash memory address (hexadecimal).

### \<size>
Read size [byte] (decimal, up to 4096).

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -rv FF200000 4096
```

## -format \<type>
Selects the file format for the `-read` option.

### \<type>
Select the type from the following list.  
|Type|Meaning|
|---|---|
|srec|Motorola S-Record (default)|
|hex|Intel Hex|

Example:
```
rfp-cli -d RA -t e2 -format hex -r read_data.hex
```

## -view-size \<size>
Selects the view size format for the `-read-view` option.  
If the size is 2 or 4, the endian of the displayed data depends on the `-endian` option. If the `-endian` option is not specified, the data will be displayed as little endian.

### \<size>
Select the size from the following list.  
|Size|Description|
|---|---|
|1|Displays data in 1-byte units (default).|
|2|Displays data in 2-byte units.|
|4|Displays data in 4-byte units.|

Example:
```
rfp-cli -d RA -t e2 -rv 0 128 -view-size 1
rfp-cli -d RA -t e2 -rv 0 128 -view-size 4 -endian big
```

## -skip-blankread
Skips reading of blank areas in reading selected by the `-read` option.

Example:
```
rfp-cli -d RA -t e2 -r -skip-blankread read_data.mot
```

## -erase-chip
Erases all data in the flash memory of the device and clears the configuration settings.  
If the device supports an initialization function, this option will also execute the initialization command. No other options for flash memory operation can be specified at the same time as this option.

**Caution:**  
This processing does not restore the device to its state at shipment. If correct settings are not programmed for the flash options after the memory in the chip has been erased, the device will not operate.

- For RH850 family products    
When a chip is erased, the configuration settings are cleared after all other data have been erased. In other words, the optional settings of the device are all erased. Since all settings, including the settings at the time of shipment, are erased at this time, be sure to make the required settings at the same time.

Example:
```
rfp-cli -d RA -t e2 -erase-chip
```

## -dlm \<state>
Causes a transition to the specified DLM state.  
If the transition requires authentication, the console prompt will be displayed. The authentication code can be specified at the prompt with the `-auth` option.  
No other options for flash memory operation can be specified at the same time as this option.

### \<state>
Select the state from the following list.  
|State|Meaning|
|---|---|
|SSD|SSD state|
|NSECSD|NSECSD state|
|DPL|DPL state|
|LCK_DBG|LCK_DBG state|
|LCK_BOOT|LCK_BOOT state|
|RMA_REQ|RMA_REQ state|
|OEM_PL2|OEM(PL2) state|
|OEM_PL1|OEM(PL1) state|
|OEM_PL0|OEM(PL0) state|

Example:
```
rfp-cli -d RA -t e2 -dlm OEM_PL1
```

## -use-uid
Uses the unique ID for authenticating a DLM transition.  
This option can be used in the RMA_REQ state.

Example:
```
rfp-cli -d RA -t e2 -dlm RMA_REQ -use-uid -auth rmakey 000102030405060708090A0B0C0D0E0F
```

## -write32 \<addr> \<data>[,\<data>...]
Performs a read-modify-write operation on the device in 32-bit units.  
This option reads data from the device, modifies the specified 32-bit word with the given value, and writes the result back to the device.

It is recommended to use this option without other flash memory operation options.  
If combined, the other flash memory operations are executed first, followed by this read-modify-write operation.

#### Notes
- This option can be specified more than once and can be used with the -writebit option.
- If the endian is not specified, little endian is used.
- This option does not support the RL78 family.

### \<addr>
Flash memory address (hexadecimal).

### \<data>
4-byte data to be written (hexadecimal).

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -write32 FF200000 01020304,05060708
```

## -writebit \<addr> \<pos> \<bitdata>
Performs a read-modify-write operation on the device in 1-bit units.  
This option reads data from the device, modifies the specified bit with the given value, and writes the result back to the device.

It is recommended to use this option without other flash memory operation options.  
If combined, the other flash memory operations are executed first, followed by this read-modify-write operation.

#### Notes
- This option can be specified more than once and can be used with the -write32 option.
- If the endian is not specified, little endian is used.
- This option does not support the RL78 family.

### \<addr>
Flash memory address (hexadecimal).

### \<pos>
Start bit number (decimal, 0 to 31). For 4-byte units of data, the most significant bit is 31 and the least significant bit is 0.

### \<bitdata>
Data to be written (binary). Write the bit data in descending order from the specified start bit number to the least significant bit (up to 32 characters are specifiable).  

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -writebit FF200000 15 1010101010101010
```

## -key-password \<password>
Specifies the key password in hexadecimal.  
To use this option, the `-mac-password` option must also be specified.

## -mac-password \<password> 
Specifies the mac password in hexadecimal.  
To use this option, the `-key-password` option must also be specified.

Example:
```
rfp-cli -d RL78 -t e2 -key-password 000102030405060708090A0B0C0D0E0F -mac-password 101112131415161718191A1B1C1D1E1F -auth id FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF <commands...>
```

## -create-write-header
Create and write the hex data with a Product Header and Image Header.

Example:
```
rfp-cli -d DA -t jlink -p -create-write-header data.mot
```

## -noquery
Suppresses the authentication code and the OSC console prompt.

Example:
```
rfp-cli -d RH850 -t e2 -osc 16 -noquery <commands...>
```

## -log \<file>
Saves a log in a file.  
If the specified file already exists, the log is appended to the existing contents of the file.

### \<file>
File path. If the file path includes spaces, enclose the string in double-quotation marks.

Example:
```
rfp-cli -d RA -t e2 -log message.log <commands...>
```

## -nologo
Suppresses the display of the header message.

Example:
```
rfp-cli -d RA -t e2 -nologo <commands...>
```

## -noprogress
Suppresses the display of the progress of processing.

Example:
```
rfp-cli -d RA -t e2 -e -noprogress <commands...>
```

# List of Flash Options
If an address range on which an operation is not possible is included, an error message is displayed.   
The indicated error will be a pre-check result or a boot firmware error.

## Lock-bit
### -fo `lb` \<start addr>,\<end addr>[,\<start addr>,\<end addr>...]  

\<start addr>  
Start address of flash memory blocks (hexadecimal).

\<end addr>  
End address of flash memory blocks (hexadecimal).

Example:
```
-fo lb 0,1FFF,6000,7FFF
```

## OTP
### -fo `otp` \<start addr>,\<end addr>[,\<start addr>,\<end addr>...]

\<start addr>  
Start address of flash memory blocks (hexadecimal).

\<end addr>  
End address of flash memory blocks (hexadecimal).

Example:
```
-fo otp 0,1FFF,6000,7FFF
```

## Access Window (Flash Shield Window)
### -fo `aw` \<start addr>,\<end addr>  
### -fo `aw-flags` \<flag>[,\<flag>...]

\<start addr>  
Start address of flash memory blocks (hexadecimal).

\<end addr>  
End address of flash memory blocks (hexadecimal).

\<flag>  
The `aw-flags` type option has to be specified with the `aw` type option.
This option cannot be used to clear flags. Some flags can be released with the `erase-chip` option.

Select the flag from the following list.  
|Flag|Description|
|---|---|
|inside|Protects memory within the range instead of outside the range.|
|protect|Prohibits rewriting of the access window.|

Example:
```
-fo aw 5000,9FFF
-fo aw 5000,9FFF -fo aw-flags inside
```

## Flash Read Protection
### -fo `rp` \<start addr>,\<end addr>
### -fo `rp-flags` \<flag>[,\<flag>...]

\<start addr>  
Start address of flash memory blocks (hexadecimal).

\<end addr>  
End address of flash memory blocks (hexadecimal).

\<flag>  
The `rp-flags` type option has to be specified with the `rp` type option.
This option cannot be used to clear flags. Some flags can be released with the `erase-chip` option.

If all blocks are readable and only flags are set, set <start address> and <end address> to the same value. (e.g. -fo rp 0,0 -fo rp-flags protect)

Select the flag from the following list.  
|Flag|Description|
|---|---|
|protect|Prohibits rewriting of the flash read protection.|

Example:
```
-fo rp 5000,9FFF
-fo rp 5000,9FFF -fo rp-flags protect
```

## Option Bytes
### -fo `opbt` \<opbt0>,\<opbt1>,...,\<opbt7>
OPBT0 to OPBT7 can be specified.  
Since writing to only some option bytes is not possible, write to all existing OPBTs.  
The RFP ignores non-existent OPBTs (0xFFFFFFFF is specified).

\<opbt>  
OPBT data (hexadecimal). (bit31 ... 0)

Example:
```
-fo opbt 00000000,11111111,22222222,33333333,44444444,55555555,66666666,77777777
```

## Extended Option Bytes
### -fo `opbtex` \<opbt8>[,\<opbt9>,...,\<opbt15>]
OPBT8 to OPBT15 can be specified.  
Since writing to only some option bytes is not possible, write to all existing OPBTs.  
The RFP ignores non-existent OPBTs (0xFFFFFFFF is specified).

\<opbt>
OPBT data (hexadecimal). (bit31 ... 0)

Example:
```
-fo opbtex 88888888,99999999,AAAAAAAA,BBBBBBBB,CCCCCCCC,DDDDDDDD,EEEEEEEE,FFFFFFFF
```

## DLM State
### -fo `state` \<state>

\<state>  
This type of state transition does not allow authentication of the transition. If authentication is required, use the `-dlm` option alone.  
Select the state from the following list.  
|State|Meaning|
|---|---|
|SSD|SSD state|
|NSECSD|NSECSD state|
|DPL|DPL state|
|LCK_DBG|LCK_DBG state|
|LCK_BOOT|LCK_BOOT state|
|OEM_PL2|OEM_PL2 state|
|OEM_PL1|OEM_PL1 state|
|OEM_PL0|OEM_PL0 state|

Example:
```
-fo state SSD
```

## DLM Keys
### -fo `seckey` \<file>
### -fo `nonseckey` \<file>
### -fo `al2key` \<file>
### -fo `al2key1` \<file>
### -fo `al2key2` \<file>
### -fo `al2key3` \<file>
### -fo `al1key` \<file>
### -fo `al1key1` \<file>
### -fo `al1key2` \<file>
### -fo `al1key3` \<file>
### -fo `rmakey` \<file>
### -fo `rmakey1` \<file>
### -fo `rmakey2` \<file>
### -fo `rmakey3` \<file>

\<file>  
Renesas key file path. If the file path includes spaces, enclose the string in double-quotation marks.  
The key file can be created by the Security Key Management Tool.

Example:
```
-fo seckey ssd.rkey
```

### -fo `al2key-flags` \<flag>[,\<flag>...]
### -fo `al1key-flags` \<flag>[,\<flag>...]
### -fo `rmakey-flags` \<flag>[,\<flag>...]

\<flag>  
This option cannot be used to clear a flag. Some flags can be released with the `erase-chip` option.

Select the flag from the following list.  
|Flag|Description|
|---|---|
|otp|Change the storage area for AL2, AL1 or RMA Key to OTP.|

Example:
```
-fo al2key-flags otp
```

## Boundary
### -fo `boundary` \<Code Secure>,\<Code NSC>,\<Data Secure>,\<SRAM Secure>,\<SRAM NSC>
### -fo `boundary` \<Code Secure>,\<Data Secure>
### -fo `boundary` \<Code Secure>,\<Data Secure>,\<SiP Flash Secure>
### -fo `boundary` \<Code Secure>

Specify "0" for parameters that do not require configuration.

\<Code Secure>  
Size of Code Secure [KB] (decimal).

\<Code NSC>  
Size of Code Non-Secure Callable [KB] (decimal).

\<Data Secure>  
Size of Data Secure [KB] (decimal).

\<SRAM Secure>  
Size of SRAM Secure [KB] (decimal).

\<SRAM NSC>  
Size of SRAM Non-Secure Callable [KB] (decimal).

\<SiP Flash Secure>  
Size of SiP Flash Secure [KB] (decimal).

Example:
```
-fo boundary 1024,512,4,16,8
-fo boundary 256,6
-fo boundary 256,0,1536
-fo boundary 16
```

### -fo `boundary-file` \<file>

\<file>  
Renesas Partition Data file path. If the file path includes spaces, enclose the string in double-quotation marks.

Example:
```
-fo boundary-file device.rpd
```

## Security Flags
### -fo `flags` \<flag>[,\<flag>...]
This option cannot clear the flags. Some flags can be released with the `erase-chip` option.

\<flag>  
Select the flag from the following list.  
|Flag|Meaning|
|---|---|
|id|Enable ID Code Authentication|
|e|Disable Block Erase|
|p|Disable Program|
|r|Disable Read|
|b|Disable Rewriting boot cluster|
|ce|Disable Initialize Command|
|con|Disable Serial Programming<br>Disable Debugger and Serial Programming|
|icus|Enable ICU-S|
|t|Disable Test Mode|
|lckb|Disable LCK_BOOT|
|al2|Disable AL2 authentication|
|al1|Disable AL1 authentication|

#### Notes
- When specifying `b` in a device with variable boot swapping, be sure to specify BTBLS at the same time.

Example:
```
-fo flags p,r
```

## Lock bit for Configuration Data
### -fo `optlb` \<lockbits>

\<lockbits>  
Specify 18-byte data concatenated with the following option setting memory data (hexadecimal).  

\- CFGD0LOCK (Configuration Data 0 Lock bit)  
\- CFGD1LOCK (Configuration Data 1 Lock bit)  
\- CFGD2LOCK (Configuration Data 2 Lock bit)  

Example:
```
CFGD0LOCK: 0001020304050607  
CFGD1LOCK: 08090A0B0C0D0E0F  
CFGD2LOCK: 1011  

-fo optlb 000102030405060708090A0B0C0D0E0F1011
```

## Anti-Rollback Counter Configuration
### -fo `arcc` \<arcc_data>

\<arcc_data>  
Specify 4-byte data concatenated with the following option setting memory data (hexadecimal). 

\- ARCCS (Anti-Rollback Counter Configuration Setting for Non-secure Application)  
\- ARCLS (Anti-Rollback Counter Lock Setting)  

Example:
```
ARCCS: 0102  
ARCLS: 0304  

-fo arcc 01020304
```

## OEM root public key
### -fo `oemrootkey0` \<file>
### -fo `oemrootkey1` \<file>
### -fo `oemrootkey2` \<file>
### -fo `oemrootkey3` \<file>
### -fo `oemrootkey-flags` \<flag>[,\<flag>...]

\<file>  
Renesas key file path. If the file path includes spaces, enclose the string in double-quotation marks.  
The key file can be created by the Security Key Management Tool.

\<flag>  
Select the flag from the following list.  
|Flag|Description|
|---|---|
|protect|Prohibits rewriting of oemrootkey0.|

Example:
```
-fo oemrootkey0 oemkey.rkey
```

## Certificate
### -fo `cert-code` \<file>
### -fo `cert-key` \<file>

\<file>  
Code certificate file and Key certificate file.  

Example:
```
-fo cert-code ccert.bin
-fo cert-key kcert.bin
```

### -fo `cert-flags` \<flag>[,\<flag>...]

If this option is not specified, Mode1 will be used. 

Select the flag from the following list.  
|Flag|Description|
|---|---|
|mode2|Change the Anti-rollback counter mode for Mode1 to Mode2.|

Example:
```
-fo cert-flags mode2
```

## ID Code Setting
### -fo `id` \<code>  

All-0xFF code. (default)

\<code>  
Specifies the authentication code in hexadecimal.

Example:
```
-fo id 0123456789ABCDEF0123456789ABCDEF
```

## CFPW Setting
### -fo `cfpw` \<code>  

All-0xFF code. (default)

\<code>  
Specifies the authentication code in hexadecimal.

Example:
```
-fo cfpw 0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF
```

## DFPW Setting
### -fo `dfpw` \<code>  

All-0xFF code. (default)

\<code>  
Specifies the authentication code in hexadecimal.

Example:
```
-fo cfpw 0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF0123456789ABCDEF
```

## Extra Option
### -fo ex \<data>
### -fo ex-flags \<flag>[,\<flag>...]
The `ex-flags` type option has to be specified with the `ex` type option.  
This option cannot clear the flags. Some flags can be released with the `erase-chip` option.

\<data>  
Extra data (hexadecimal).

\<flag>  
Select the flag from the following list.  
|Flag|Description|
|---|---|
|protect|Prohibits rewriting of extra options.|

Example:
```
-fo ex 000102030405060708090A0B0C
```

## BTBLS
### -fo `btbls` \<btbls>
### -fo `btbls-flags` \<flag>[,\<flag>...]
 
Specify the value of BTBLS[3:0] for the setting of the boot cluster size in an RL78 device.

\<btbls>  
Specify 1-byte data for BTBLS in hexadecimal. The four higher-order bits are ignored when writing data.

\<flag>  
The `btbls-flags` type option has to be specified with the `btbls` type option.

When the "btbls" option has been set, this flag is set as "protect" by default.  
Therefore, this flag does not usually require specification.
 
Select the flag from the following list. 
|Flag|Description|
|---|---|
|none|No protection. (BAPR = 1)|
|protect|Prohibits rewriting of BTBLS. (BAPR = 0) (default)|
 
Example:
```
-fo btbls 05
```

## CPU Settings
### -fo `cpuflags` \<flag>[,\<flag>...]
 
\<flag>  
Select the flag from the following list. 
|Flag|Description|
|---|---|
|cpu1|Change master CPU from CPU0 to CPU1.|
|nosecex|Disable security extension for CPU1.|

Example:
```
-fo cpuflags cpu1
```

## SiP Flash
### -fo `sip-statusreg` \<statusreg_data>

\<statusreg_data>  
Specify 1-byte data for Status Register of SiP Flash (hexadecimal).

Example:
```
-fo sip-statusreg 40
```

### -fo `sip-pmr` \<pmr_data>  

\<pmr_data>  
Specify 1-byte data for Protection Management Register of SiP Flash (hexadecimal).

Example:
```
-fo sip-pmr 7F
```

## User Extra
### -fo `userextra-flags` \<flag>[,\<flag>...]

\<flag> 
Select the flag from the following list. 
|Flag|Description|
|---|---|
|wp-on|Enable Write protection for User Extra Area.|
|wp-off|Disable Write protection for User Extra Area.|

Example:
```
-fo userextra-flags wp-on
```

# Options for External Flash

## -external-loader \<name>
Enables external flash programming and loading of an external flash loader file.

\<name>  
Specify the Name key string. The Name key can be obtained with the `-list-external-loader` option.

Example:
```
rfp-cli -d RA -t e2 -external-loader EK-RA8M1 <commands...>
```

## -show-external-loader \<name>
Shows detailed information on the settings of the external loader.

\<name>  
Specify the Name key string. The Name key can be obtained with the `-list-external-loader` option.

Example:
```
rfp-cli -d RA -t e2 -show-external-loader EK-RA8M1
```

## -list-external-loader
Displays a list of name keys for use in setting the external loader.

Example:
```
rfp-cli -d RA -t e2 -list-external-loader
```
